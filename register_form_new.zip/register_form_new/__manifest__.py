{
    'name': 'Registration Form new',
    'version': '1.0',
    'category': 'Custom',
    'summary': 'Module to manage register forms',
    'description': 'This module provides a model to manage register forms.',
    'author': 'Your Name',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',

        "views/education.xml",
        "views/designation.xml",
        "views/Country.xml",

        "views/state.xml",
        "views/rasi.xml",
        'views/star.xml',
        "views/marital.xml",


        'views/reg_form.xml',
    ],
    'installable': True,
    'application': True,
}
